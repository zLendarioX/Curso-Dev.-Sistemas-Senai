package Main;

import java.util.ArrayList;
import Models.Produto;

import java.util.Scanner;
public class index {
  public static void main(String[] args) {
	  
	Scanner scan = new Scanner(System.in);
    ArrayList<Produto> productList = new ArrayList<>();
    
    Produto product = new Produto();
    int indice = 0;
    int op = 0;
    boolean val = true;
	while (val == true) {
		System.out.println("\n\nSelecione uma opção\n"
				+ "1 - Prdutos\n"
				+ "2 - Cadastrar Produto\n"
				+ "3 - Excluir Produto\n"
				+ "4 - Atualizar estoque Produto\n"
				+ "5 - Fechar Sistema\n");
		int opc = scan.nextInt();
		switch(opc) {
		case 1:
			System.out.println("Produtos Cadastrados");
			  for (int i = 0; i < productList.size(); i++) {
				  product = productList.get(i);
			      System.out.printf("%d - %s - %d", i +1, product.getNome(), product.getEstoque());
			  }
			  break;
		case 2: 
			System.out.println("Cadastrar Produto");
			System.out.println("Informeo nome: ");
			String nomep = scan.next();
			System.out.println("Informeo o valor: ");
			double preco = scan.nextDouble();
			System.out.println("Informeo Estoque: ");
			int estoque = scan.nextInt();
			
			product.setNome(nomep);
			    
		    product.setPreco(preco);
		    
		    product.setEstoque(estoque);
		    
		    productList.add(product);
		    
		    System.out.println("O produto foi cadastrado com sucesso");
		    break;
		case 3:
			
			for (int i = 0; i < productList.size(); i++) {
				  product = productList.get(i);
			      System.out.printf("%d - %s - %d\n", i +1, product.getNome(), product.getEstoque());
			 }
			System.out.println("Qual produto você deseja apagar: ");
			indice = scan.nextInt() - 1;
			
			product = productList.get(indice);
			
			 System.out.printf("Voce realmente deseja deletar esse produto\n"
			 		+ "%d - %s \n"
			 		+ "[ 1 ] Sim\n"
			 		+ "[ 2 ] Não", indice +1, product.getNome());
			 op = scan.nextInt();
			 if(op == 1) {
				 productList.remove(indice);
				 System.out.printf("O produto foi removido");
			 } else {
				 System.out.printf("O produto não foi removido");
			 }
			break;
		case 4:
			for (int i = 0; i < productList.size(); i++) {
				  product = productList.get(i);
			      System.out.printf("%d - %s - %d\n", i +1, product.getNome(), product.getEstoque());
			 }
			System.out.println("Qual produto você deseja editar o estoque: ");
			indice = scan.nextInt() - 1;
			
			product = productList.get(indice);
			
			
			System.out.printf("Informe a quantia que será removida:\n");
			int quant = scan.nextInt();
			quant = product.getEstoque() - quant;
			product.setEstoque(quant);
			
			System.out.println("Estoque atualizado");
			break;
		case 5:
				System.out.println("Sistema fechado");
				 val = false;
			  break;
		default:
			  break;
		}
	}
    
    scan.close();
  }
}